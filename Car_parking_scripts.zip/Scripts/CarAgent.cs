﻿using System.Collections.Generic;
using Unity.MLAgents.Policies;
using Unity.MLAgents.Sensors;
using UnityEngine;
using static CarController;

public class CarAgent : BaseAgent
{
    private Vector3 originalPosition;

    private BehaviorParameters behaviorParameters;

    private CarController carController;

    private Rigidbody carControllerRigidBody;

    private CarSpots carSpots;

    private int HiddenCar = -1;

    private int ciriculumExploreLimit = 10000;

    private float BestAvgReward = 0.5f * 5.0f;

    private float TotalEpisodeReward = 0.0f;

    private Dictionary<int, float> ciriculum = new Dictionary<int, float>()
    {
        {0, 0.0f}, {1, 0.0f}, {2, 0.0f}, {3, 0.0f}, {4, 0.0f}, {5, 0.0f}, {6, 0.0f}, {7, 0.0f}
    };

    private Dictionary<int, int> ciriculumCounts = new Dictionary<int, int>()
    {
        {0, 0}, {1, 0}, {2, 0}, {3, 0}, {4, 0}, {5, 0}, {6, 0}, {7, 0}
    };

    public override void Initialize()
    {
        originalPosition = transform.localPosition;
        behaviorParameters = GetComponent<BehaviorParameters>();
        carController = GetComponent<CarController>();
        carControllerRigidBody = carController.GetComponent<Rigidbody>();
        carSpots = transform.parent.GetComponentInChildren<CarSpots>();

        HiddenCar = ResetParkingLotArea(true, 0);    
    }

    public override void OnEpisodeBegin()
    {
        if (transform.localPosition == null)
        {
            Debug.Log("transform is null");
        }
        else
        {
            Debug.Log("transform is not null" + transform.localPosition.ToString());
        }
        TotalEpisodeReward = 0.0f;
        
        if (CompletedEpisodes == ciriculumExploreLimit)
        {
            Debug.Log("Reached Limit of Exploration");
        }
        
        if (CompletedEpisodes < ciriculumExploreLimit)
        {
            HiddenCar = ResetParkingLotArea(true, 0);
        }

        else
        {
            int maxRewardKey = -1;
            float maxRewardValue = float.MinValue;

            foreach (var item in ciriculum)
            {
                if (item.Value > maxRewardValue & item.Value < BestAvgReward)
                {
                    maxRewardKey = item.Key;
                    maxRewardValue = item.Value;
                }
            }

            if (maxRewardKey != -1)
            {
                HiddenCar = ResetParkingLotArea(false, maxRewardKey);
            }
            else
            {
                Debug.Log("Best Avg Reward reached for all states! Going Random now");
                Debug.Log("0=" + ciriculum[0].ToString() + " 1=" + ciriculum[1].ToString() + " 2=" + ciriculum[2].ToString() + " 3=" + ciriculum[3].ToString() + " 4=" + ciriculum[4].ToString() + " 5=" + ciriculum[5].ToString() + " 6=" + ciriculum[6].ToString() + " 7=" + ciriculum[7].ToString());
                HiddenCar = ResetParkingLotArea(true, 0);
            }
            //Debug.Log("Hiding Car " + maxRewardKey.ToString() + "for episode=" + CompletedEpisodes.ToString());
        }

        ciriculumCounts[HiddenCar] += 1;
    }

    private int ResetParkingLotArea(bool random=true, int hideCarNum=0)
    {
        int hidCarIdx;
        // important to set car to automonous during default behavior
        carController.IsAutonomous = behaviorParameters.BehaviorType == BehaviorType.Default;
        transform.localPosition = originalPosition;
        transform.localRotation = Quaternion.identity;
        carControllerRigidBody.velocity = Vector3.zero;
        carControllerRigidBody.angularVelocity = Vector3.zero;

        // reset which cars show or not show
        if (random == true)
        {
            hidCarIdx = carSpots.Setup(random, hideCarNum);
        }
        else
        {
            hidCarIdx = carSpots.Setup(random, hideCarNum);
        }
        
        return hidCarIdx;
    }

    void Update()
    {
        if(transform.localPosition.y <= 0)
        {
            TakeAwayPoints();
        }
    }

    public override void CollectObservations(VectorSensor sensor)
    {
        sensor.AddObservation(transform.localPosition);
        sensor.AddObservation(transform.rotation);

        sensor.AddObservation(carSpots.CarGoal.transform.position);
        sensor.AddObservation(carSpots.CarGoal.transform.rotation);

        sensor.AddObservation(carControllerRigidBody.velocity);
    }
    
    public override void OnActionReceived(float[] vectorAction)
    {
        var direction = Mathf.FloorToInt(vectorAction[0]);

        switch (direction)
        {
            case 0: // idle
                carController.CurrentDirection = Direction.Idle;
                break;
            case 1: // forward
                carController.CurrentDirection = Direction.MoveForward;
                break;
            case 2: // backward
                carController.CurrentDirection = Direction.MoveBackward;
                break;
            case 3: // turn left
                carController.CurrentDirection = Direction.TurnLeft;
                break;
            case 4: // turn right
                carController.CurrentDirection = Direction.TurnRight;
                break;
        }

        AddReward(-1f / MaxStep);
        TotalEpisodeReward += -1f / MaxStep;
    }

    public void GivePoints(float amount = 1.0f, bool isFinal = false)
    {
        AddReward(amount);
        TotalEpisodeReward += amount;

        if (isFinal)
        {
            StartCoroutine(SwapGroundMaterial(successMaterial, 0.5f));
            ciriculum[HiddenCar] = (ciriculum[HiddenCar] * (ciriculumCounts[HiddenCar] - 1) + TotalEpisodeReward) / ciriculumCounts[HiddenCar];
            //Debug.Log("Reward=" + TotalEpisodeReward.ToString());
            EndEpisode();
        }
    }

    public void TakeAwayPoints()
    {
        StartCoroutine(SwapGroundMaterial(failureMaterial, 0.5f));

        AddReward(-0.01f);
        TotalEpisodeReward += -0.01f;
        //Debug.Log("Reward=" + TotalEpisodeReward.ToString());
        ciriculum[HiddenCar] = (ciriculum[HiddenCar] * (ciriculumCounts[HiddenCar] - 1) + TotalEpisodeReward) / ciriculumCounts[HiddenCar]; 
        EndEpisode();
    }

    public override void Heuristic(float[] actionsOut)
    {
        actionsOut[0] = 0;

        if(Input.GetKey(KeyCode.UpArrow))
        {
            actionsOut[0] = 1;
        }

        if(Input.GetKey(KeyCode.DownArrow))
        {
            actionsOut[0] = 2;
        }

        if(Input.GetKey(KeyCode.LeftArrow) && carController.canApplyTorque())
        {
            actionsOut[0] = 3;
        }

        if(Input.GetKey(KeyCode.RightArrow) && carController.canApplyTorque())
        {
            actionsOut[0] = 4;
        }
    }
}
