-Instructions to run the rover driver:

1. Run Roversim.x86_64 to start the simulator. 
2. Choose the appropriate graphics settings and start the simulator.
3. Choose Autonomous mode option in the simulator.
4. Run the driver python file at code/drive_rover.py
5. The driver creates a socket and waits for the simulator to connect. Then,
it starts the process of mapping the environment and collecting the goals.
